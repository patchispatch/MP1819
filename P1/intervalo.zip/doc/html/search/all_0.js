var searchData=
[
  ['comprobarvacio',['comprobarVacio',['../intervalo_8h.html#a4414e0616dd83662f4b657056c06c5fe',1,'comprobarVacio(Intervalo i):&#160;intervalo.cpp'],['../intervalo_8cpp.html#af04754c0b696dbfdab957682cd4af7d2',1,'comprobarVacio(Intervalo obj):&#160;intervalo.cpp']]]
];
