var searchData=
[
  ['dentrocotainf',['dentroCotaInf',['../classIntervalo.html#aac8f7b98dd0d702086ea897f5c9ad932',1,'Intervalo']]],
  ['dentrocotasup',['dentroCotaSup',['../classIntervalo.html#aed0964a68d4b727bd104f5128ee7a7ef',1,'Intervalo']]]
];
