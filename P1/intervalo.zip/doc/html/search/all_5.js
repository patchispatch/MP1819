var searchData=
[
  ['leer',['leer',['../intervalo_8h.html#a81ca561257a3eea794e139a64fdd6593',1,'leer(Intervalo &amp;i):&#160;intervalo.cpp'],['../intervalo_8cpp.html#af4a52a4cb7d127beb07eba78a088f65e',1,'leer(Intervalo &amp;obj):&#160;intervalo.cpp']]]
];
