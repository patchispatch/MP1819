var searchData=
[
  ['getcotainf',['getCotaInf',['../classIntervalo.html#aafa3f6ec78c6bd44b568e343fb22fc90',1,'Intervalo']]],
  ['getcotasup',['getCotaSup',['../classIntervalo.html#a2dd767a860e4e85ec3d5a44e78884b76',1,'Intervalo']]]
];
