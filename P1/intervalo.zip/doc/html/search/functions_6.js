var searchData=
[
  ['setintervalo',['setIntervalo',['../classIntervalo.html#a3e7cfa7c148a4e60be7040fecf506313',1,'Intervalo']]]
];
